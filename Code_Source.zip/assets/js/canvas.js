var canvasE = {
    canvas : document.getElementById("canvas"),
    ctx : canvas.getContext("2d"),
    mouse : {x: 0, y: 0},


    
    initCanvas(){
        canvasE.canvas.addEventListener('mousemove', function(e){
            canvasE.mouse.x = e.offsetX
            canvasE.mouse.y = e.offsetY
        }, false);

        canvasE.ctx.lineWidht = 3;
        canvasE.ctx.lineJoin = "round";
        canvasE.ctx.lineCap = "round";
        canvasE.ctx.strokeStyle = "black";

        canvasE.canvas.addEventListener('mousedown', function(e){
            canvasE.ctx.beginPath();
            canvasE.ctx.moveTo(canvasE.mouse.x, canvasE.mouse.y);
            canvasE.canvas.addEventListener('mousemove', onPaint, false);
        }, false);
    
        canvasE.canvas.addEventListener('mouseup', function(e){
            reservation.canvasCheck = "OK";
            canvasE.canvas.removeEventListener('mousemove', onPaint, false);
        }, false);

        onPaint = function() {
            canvasE.ctx.lineTo(canvasE.mouse.x, canvasE.mouse.y);
            canvasE.ctx.stroke();
        }
    },

    clear(){
        canvasE.ctx.clearRect(0, 0, canvas.width, canvas.height);
    },
}