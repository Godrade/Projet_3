
var sliderOption = {
  i : 0,
  time : 5000,
  Slider : "" ,
  pauseSlide : document.getElementById('pause'),

  init(tableau){
    this.Slider = tableau ;
  },

  addi(){
    this.i++;
  },

  removei(){
    this.i--;
  },

  reseti(){
    this.i = 0;
  },

  autoPlay(){
    if(this.i < this.Slider.length - 1){
      this.addi();
      this.updateImg();
    } else { 
      this.reseti();
      this.updateImg();
    }
    this.addTimer();
  },

  addTimer(){
    sliderTimer = setTimeout("sliderOption.autoPlay()", this.time);
  },

  updateImg(){
    document.slide.src = this.Slider[this.i].url;
  },

  arriere(){
    if(this.i < 1 ){
      this.i = this.Slider.length - 1;
      this.updateImg();
    }else{
      this.removei();
      this.updateImg();
    }
  },

  avant(){
    if(this.i === this.Slider.length - 1){
      this.reseti();
      this.updateImg();
    }else{
      this.addi();
      this.updateImg();
    }
  },

  pauseSlider(){
    clearInterval(sliderTimer);
    this.pauseSlide.style.display = 'flex';
    console.log('AutoPlay Désactivé');
  },

  playSlider(){
    this.autoPlay();
    this.pauseSlide.style.display = 'none';
    console.log('AutoPlay réactivé');
  },

  keyboardDetect(){
    $(document).keydown(function(e){
      switch (e.which){
        case 37: // fleche gauche
          sliderOption.arriere();
        break;
        case 39: // fleche droite
          sliderOption.avant();
        break;
      }
   }); 
  }
}