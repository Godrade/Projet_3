// SLIDER
const Tableau = [
      {url : "assets/img/3.jpg"},
      {url : "assets/img/0.jpg"},
      {url : "assets/img/1.jpg"},
      {url : "assets/img/2.jpg"}
    ];

    sliderOption.init(Tableau);
    sliderOption.keyboardDetect();
    sliderOption.autoPlay();


    $('.avant').click(function()
	{
        sliderOption.avant();
    });

    $('.arriere').click(function()
	{
        sliderOption.arriere();
    });

    $('.image_slider').click(function()
	{
        sliderOption.pauseSlider();
    });

    $('#pause').click(function(){
        sliderOption.playSlider();
    });

    // MAPS

    maps.initMap();
    maps.apiMap();

    // RESERVATION

    reservation.localNameCheck();
    reservation.checkReservation();

    $('#form_contact').submit(function(e){
        reservation.localName();

        reservation.canvasBlock.style.display = "block";
        reservation.btnClick.style.display = "none";
        
        e.preventDefault();
    });

    $('#btnConfirm').click(function(e){
        reservation.startReservation();
    }); 

    $('#annuler').click(function(e){
        reservation.annuler();
    }); 


    // CANVAS
    canvasE.initCanvas();
